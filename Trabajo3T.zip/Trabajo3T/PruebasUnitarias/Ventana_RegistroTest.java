package PruebasUnitarias;

import static org.junit.Assert.*;
import org.junit.Test;

import Aplicacion.Ventana_Registro;

import javax.swing.JButton;

public class Ventana_RegistroTest {

    @Test
    //Ventana Registro se crea bien
    public void testVentanaRegistroSeCreaCorrectamente() {
        Ventana_Registro ventana = new Ventana_Registro();
        assertNotNull("La ventana debe crearse", ventana);
    }


    @Test
    //Boton corfimar correcto
    public void testBotonConfirmarTextoCorrecto() {
        Ventana_Registro ventana = new Ventana_Registro();
        JButton boton = (JButton) ventana.getContentPane().getComponent(4);
        assertEquals("Confirmar", boton.getText());
    }
}
