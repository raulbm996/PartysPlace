package PruebasUnitarias;

import static org.junit.Assert.*;
import org.junit.Test;

import Aplicacion.Ventana2;

import javax.swing.JButton;

public class Ventana2Test {

    @Test
    //Comprobamos que Ventana2 se crea bien
    public void testVentana2SeCreaCorrectamente() {
        Ventana2 ventana = new Ventana2();
        assertNotNull("La ventana Ventana2 no debe ser nula", ventana);
    }

    @Test
    //Boton registrar existe 
    public void testBotonRegistrarseExiste() {
        Ventana2 ventana = new Ventana2();
        JButton boton = (JButton) ventana.getContentPane().getComponent(0);
        assertEquals("Registrarse", boton.getText());
    }

    @Test
    //Boton Iniciar Sesion existe
    public void testBotonIniciarSesionExiste() {
        Ventana2 ventana = new Ventana2();
        JButton boton = (JButton) ventana.getContentPane().getComponent(1);
        assertEquals("Iniciar Sesión", boton.getText());
    }
}
