package PruebasUnitarias;

import static org.junit.Assert.*;
import org.junit.Test;

import Aplicacion.VentanaPrincipal;

import javax.swing.JButton;
import javax.swing.JTextArea;

public class VentanaPrincipalTest {

    @Test
    //Comprobamos que la ventana se crea correctamente
    public void testVentanaPrincipalSeCreaCorrectamente() {
        VentanaPrincipal ventana = new VentanaPrincipal();
        assertNotNull("La ventana no debe ser nula", ventana);
    }

    @Test
    //Comprobamos que el boton continuar existe
    public void testBotonContinuarExiste() {
        VentanaPrincipal ventana = new VentanaPrincipal();
        JButton boton = (JButton) ventana.getContentPane().getComponent(0);
        assertEquals("Continuar", boton.getText());
    }

    @Test
    //Compronamos que el textArea tiene contenido
    public void testTextoAreaTieneContenido() {
        VentanaPrincipal ventana = new VentanaPrincipal();
        JTextArea texto = (JTextArea) ventana.getContentPane().getComponent(1);
        assertTrue("El área de texto debe tener contenido", texto.getText().length() > 0);
    }
}

