package Aplicacion;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JTextArea;
import java.awt.Color;
import javax.swing.JButton;

public class Ventana_InicioSesion extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Ventana_InicioSesion frame = new Ventana_InicioSesion();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Ventana_InicioSesion() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 255, 128));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Iniciar Sesión");
		lblNewLabel.setForeground(new Color(255, 255, 255));
		lblNewLabel.setFont(new Font("Arial", Font.BOLD, 18));
		lblNewLabel.setBounds(172, 10, 155, 26);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Correo:");
		lblNewLabel_1.setForeground(new Color(255, 255, 255));
		lblNewLabel_1.setFont(new Font("Arial", Font.BOLD, 15));
		lblNewLabel_1.setBounds(91, 137, 72, 13);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Contraseña:");
		lblNewLabel_2.setForeground(new Color(255, 255, 255));
		lblNewLabel_2.setFont(new Font("Arial", Font.BOLD, 15));
		lblNewLabel_2.setBounds(91, 180, 106, 13);
		contentPane.add(lblNewLabel_2);
		
		JTextArea txtCorreo = new JTextArea();
		txtCorreo.setBounds(198, 132, 106, 22);
		contentPane.add(txtCorreo);
		
		JTextArea txtContraseña = new JTextArea();
		txtContraseña.setBounds(198, 175, 106, 22);
		contentPane.add(txtContraseña);
		
		JButton btnConfirmar = new JButton("Confirmar");
		btnConfirmar.setFont(new Font("Arial", Font.BOLD, 15));
		btnConfirmar.setBounds(305, 227, 121, 26);
		contentPane.add(btnConfirmar);
		
		JLabel lblfondo = new JLabel("PartysPlace");
		lblfondo.setBounds(-14, 0, 462, 284);
		lblfondo.setFont(new Font("Arial", Font.BOLD, 18));
		contentPane.add(lblfondo);
		contentPane.setLayout(null);
		
			ImageIcon icono2= new ImageIcon(Ventana_InicioSesion.class.getResource("/imagenes/ChatGPT Image 19 may 2025, 12_20_18.png"));
			Image imagen2 = icono2.getImage().getScaledInstance( lblfondo.getWidth(),lblfondo.getHeight(), Image.SCALE_SMOOTH);
			ImageIcon iconoAjustado2 = new ImageIcon(imagen2);

			lblfondo.setIcon(iconoAjustado2);
		
		btnConfirmar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String correo = txtCorreo.getText();
				String contraseña = txtContraseña.getText();
				
				ConexionMySQL conexion = new ConexionMySQL("root", "", "aplicacion");
		        try {
					conexion.conectar();
					
					
					String SQL = "SELECT * FROM registro WHERE correo = '"+correo+"' AND contraseña = '"+contraseña+"'";
					conexion.ejecutarSelect(SQL);
					
					//ResultSet es una clase para analizar consultas select
					ResultSet rs = conexion.ejecutarSelect(SQL);
					if(rs.next()) {
						//Si el usuario y contraseñas son validos se ejecuta este bloque
						Ventana3 afterLogin = new Ventana3();
						afterLogin.setVisible(true);
						dispose();
					} else {
						//Si el usuario y contraseña son validos no se ejecuta este bloque
						JOptionPane.showMessageDialog(null, "Usuario o contraseña incorrecto");
					}
					
					conexion.desconectar();
					dispose();
					
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				
			}
			
		});	
	}
}
