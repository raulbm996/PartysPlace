package Aplicacion;

import java.awt.EventQueue;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextArea;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Color;
import javax.swing.JMenu;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;

public class Ventana3 extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Ventana3 frame = new Ventana3();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Ventana3() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnNewButton = new JButton("Confirmar");
		btnNewButton.setForeground(new Color(0, 0, 0));
		btnNewButton.setFont(new Font("Arial", Font.BOLD, 16));
		btnNewButton.setBounds(274, 232, 129, 21);
		contentPane.add(btnNewButton);
		
		textField = new JTextField();
		textField.setColumns(10);
		textField.setBounds(183, 182, 96, 19);
		contentPane.add(textField);
		
		JTextArea txtrC = new JTextArea();
		txtrC.setForeground(new Color(255, 255, 255));
		txtrC.setOpaque(false); // Hace que no se pinte el fondo
		txtrC.setLineWrap(true);
		txtrC.setText("¿En que ciudad está interesado en ir?");
		txtrC.setFont(new Font("Arial", Font.BOLD, 17));
		txtrC.setBounds(82, 130, 323, 61);
		contentPane.add(txtrC);
		
		JLabel lblfondo = new JLabel("PartysPlace");
		lblfondo.setBounds(-14, 0, 462, 284);
		lblfondo.setFont(new Font("Arial", Font.BOLD, 18));
		contentPane.add(lblfondo);
		contentPane.setLayout(null);
		
			ImageIcon icono2= new ImageIcon(Ventana3.class.getResource("/imagenes/ChatGPT Image 19 may 2025, 12_20_18.png"));
			Image imagen2 = icono2.getImage().getScaledInstance( lblfondo.getWidth(),lblfondo.getHeight(), Image.SCALE_SMOOTH);
			ImageIcon iconoAjustado2 = new ImageIcon(imagen2);

			lblfondo.setIcon(iconoAjustado2);
			
			btnNewButton.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e) {
					
					if(textField.getText().equals("Sevilla"))
					{
						Sevilla G = new Sevilla();
						G.setVisible(true);						
					}else if (textField.getText().equals("Ibiza")) 
					{
						Ibiza G = new Ibiza();
						G.setVisible(true);	
					}else if(textField.getText().equals("Madrid")) 
					{
						Madrid G = new Madrid();
						G.setVisible(true);
					}else if(textField.getText().equals("Alicante")) 
					{
						Alicante G = new Alicante();
						G.setVisible(true);
					}else if (textField.getText().equals("Cadiz")) 
					{
						Cadiz G = new Cadiz();
						G.setVisible(true);
					}else if(textField.getText().equals("Murcia")) 
					{
						Murcia G = new Murcia();
						G.setVisible(true);
					}else {
						JOptionPane.showInternalMessageDialog(null, "No se ha encontrado ninguna ciudad con ese nombre. Introduzca alguno de estos: Sevilla, Ibiza, Madrid, Alicante, Cadiz o Murcia.", "Error", JOptionPane.INFORMATION_MESSAGE);
					
				}
			}
	
			
			
			
	
			});
	}
}
