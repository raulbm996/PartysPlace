package Aplicacion;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextArea;
import java.awt.Color;

public class Ibiza extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Ibiza frame = new Ibiza();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Ibiza() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		
		JLabel foto1 = new JLabel("");  
		foto1.setBounds(22, 131, 126, 108);  // Ventana pequeña
		foto1.setFont(new Font("Arial", Font.BOLD, 18));
		contentPane.setLayout(null);
		
		JTextArea txtrUshuaiaCtraDe = new JTextArea();
		txtrUshuaiaCtraDe.setWrapStyleWord(true);
		txtrUshuaiaCtraDe.setText("Ushuaia Ctra. de Platja d'en Bossa, 10, 07817 Sant Jordi de ses Salines, Illes Balears");
		txtrUshuaiaCtraDe.setOpaque(false);
		txtrUshuaiaCtraDe.setLineWrap(true);
		txtrUshuaiaCtraDe.setForeground(Color.WHITE);
		txtrUshuaiaCtraDe.setFont(new Font("Arial", Font.BOLD, 16));
		txtrUshuaiaCtraDe.setBackground(Color.WHITE);
		txtrUshuaiaCtraDe.setBounds(181, 132, 196, 93);
		contentPane.add(txtrUshuaiaCtraDe);
		
		JTextArea txtrIbiza = new JTextArea();
		txtrIbiza.setText("Ibiza");
		txtrIbiza.setOpaque(false);
		txtrIbiza.setForeground(Color.WHITE);
		txtrIbiza.setFont(new Font("Arial", Font.BOLD, 18));
		txtrIbiza.setBackground(Color.BLACK);
		txtrIbiza.setBounds(181, 10, 76, 22);
		contentPane.add(txtrIbiza);
		contentPane.add(foto1);

		// Cargar imagen y ajustarla al tamaño del JLabel
		ImageIcon icono3 = new ImageIcon(Sevilla.class.getResource("/imagenes/ushuaia.jpg"));
		Image imagen3 = icono3.getImage().getScaledInstance(foto1.getWidth(), foto1.getHeight(), Image.SCALE_SMOOTH);
		ImageIcon iconoAjustado3 = new ImageIcon(imagen3);

		// Asignar la imagen ajustada al JLabel 'foto1'
		foto1.setIcon(iconoAjustado3);
		
		JLabel lblfondo = new JLabel("PartysPlace");
		lblfondo.setBounds(-14, 0, 462, 284);
		lblfondo.setFont(new Font("Arial", Font.BOLD, 18));
		contentPane.add(lblfondo);
		contentPane.setLayout(null);
		
			ImageIcon icono2= new ImageIcon(Sevilla.class.getResource("/imagenes/ChatGPT Image 19 may 2025, 12_20_18.png"));
			Image imagen2 = icono2.getImage().getScaledInstance( lblfondo.getWidth(),lblfondo.getHeight(), Image.SCALE_SMOOTH);
			ImageIcon iconoAjustado2 = new ImageIcon(imagen2);

			lblfondo.setIcon(iconoAjustado2);
			contentPane.setLayout(null);
			
	}

}
