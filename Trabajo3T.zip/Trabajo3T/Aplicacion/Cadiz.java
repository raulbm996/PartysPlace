package Aplicacion;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.border.EmptyBorder;

public class Cadiz extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Cadiz frame = new Cadiz();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Cadiz() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		
		JTextArea txtrBluPuertoSherry = new JTextArea();
		txtrBluPuertoSherry.setWrapStyleWord(true);
		txtrBluPuertoSherry.setText("Blu Puerto Sherry Calle Puerto Serrano 9, Puerto Sherry, 11500 El Puerto de Sta María, Cádiz");
		txtrBluPuertoSherry.setOpaque(false);
		txtrBluPuertoSherry.setLineWrap(true);
		txtrBluPuertoSherry.setForeground(Color.WHITE);
		txtrBluPuertoSherry.setFont(new Font("Arial", Font.BOLD, 16));
		txtrBluPuertoSherry.setBackground(Color.WHITE);
		txtrBluPuertoSherry.setBounds(166, 132, 196, 93);
		contentPane.add(txtrBluPuertoSherry);
		
		JTextArea txtrSevilla = new JTextArea();
		txtrSevilla.setOpaque(false); // Hace que no se pinte el fondo
		txtrSevilla.setBackground(new Color(0, 0, 0));
		txtrSevilla.setFont(new Font("Arial", Font.BOLD, 18));
		txtrSevilla.setForeground(new Color(255, 255, 255));
		txtrSevilla.setText("Cadiz");
		txtrSevilla.setBounds(188, 10, 76, 22);
		contentPane.add(txtrSevilla);
		
		JLabel foto1 = new JLabel("");  
		foto1.setBounds(22, 131, 126, 108);  // Ventana pequeña
		foto1.setFont(new Font("Arial", Font.BOLD, 18));
		contentPane.setLayout(null);
		contentPane.add(foto1);

		// Cargar imagen y ajustarla al tamaño del JLabel
		ImageIcon icono3 = new ImageIcon(Sevilla.class.getResource("/imagenes/blu.jpg"));
		Image imagen3 = icono3.getImage().getScaledInstance(foto1.getWidth(), foto1.getHeight(), Image.SCALE_SMOOTH);
		ImageIcon iconoAjustado3 = new ImageIcon(imagen3);

		// Asignar la imagen ajustada al JLabel 'foto1'
		foto1.setIcon(iconoAjustado3);
		
		JLabel lblfondo = new JLabel("PartysPlace");
		lblfondo.setBounds(-14, 0, 462, 284);
		lblfondo.setFont(new Font("Arial", Font.BOLD, 18));
		contentPane.add(lblfondo);
		contentPane.setLayout(null);
		
			ImageIcon icono2= new ImageIcon(Sevilla.class.getResource("/imagenes/ChatGPT Image 19 may 2025, 12_20_18.png"));
			Image imagen2 = icono2.getImage().getScaledInstance( lblfondo.getWidth(),lblfondo.getHeight(), Image.SCALE_SMOOTH);
			ImageIcon iconoAjustado2 = new ImageIcon(imagen2);

			lblfondo.setIcon(iconoAjustado2);
			contentPane.setLayout(null);
	}

}
