package Aplicacion;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.Color;

public class Ventana_Registro extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField text_Nombre1;
	private JTextField text_Apellido1;
	private JTextField text_Correo1;
	private JTextField text_Contraseña1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Ventana_Registro frame = new Ventana_Registro();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Ventana_Registro() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(0, 0, 0, 0));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel text_Nombre = new JLabel("Nombre:");
		text_Nombre.setForeground(new Color(255, 255, 255));
		text_Nombre.setBounds(23, 137, 73, 13);
		text_Nombre.setFont(new Font("Arial", Font.BOLD, 15));
		contentPane.add(text_Nombre);
		
		JLabel text_Apellido = new JLabel("Apellido:");
		text_Apellido.setForeground(new Color(255, 255, 255));
		text_Apellido.setFont(new Font("Arial", Font.BOLD, 15));
		text_Apellido.setBounds(23, 177, 78, 13);
		contentPane.add(text_Apellido);
		
		JLabel text_Correo = new JLabel("Correo:");
		text_Correo.setForeground(new Color(255, 255, 255));
		text_Correo.setFont(new Font("Arial", Font.BOLD, 15));
		text_Correo.setBounds(230, 137, 58, 13);
		contentPane.add(text_Correo);
		
		JLabel text_Contraseña = new JLabel("Contraseña:");
		text_Contraseña.setForeground(new Color(255, 255, 255));
		text_Contraseña.setFont(new Font("Arial", Font.BOLD, 15));
		text_Contraseña.setBounds(228, 177, 92, 13);
		contentPane.add(text_Contraseña);
		
		JButton text_Confirmar = new JButton("Confirmar");
		text_Confirmar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				Ventana_InicioSesion G = new Ventana_InicioSesion();
				G.setVisible(true);
				
				 ConexionMySQL conexion = new ConexionMySQL("root", "", "aplicacion");
			        try {
						conexion.conectar();
						
						
						String sentencia = "INSERT INTO registro(nombre, apellidos, correo, contraseña) VALUES ('"+text_Nombre1.getText()+"','"+ text_Apellido1.getText()+"','"+text_Correo1.getText()+"','"+text_Contraseña1.getText()+"')";
						conexion.ejecutarInsertDeleteUpdate(sentencia);
						
						conexion.desconectar();
						
						dispose();
						
					} catch (SQLException e1) {
						e1.printStackTrace();
					}
			}
		});
		text_Confirmar.setFont(new Font("Arial", Font.BOLD, 18));
		text_Confirmar.setBounds(266, 232, 160, 21);
		contentPane.add(text_Confirmar);
		
		JLabel lblNewLabel_4 = new JLabel("REGISTRO");
		lblNewLabel_4.setForeground(new Color(255, 255, 255));
		lblNewLabel_4.setFont(new Font("Arial", Font.BOLD, 18));
		lblNewLabel_4.setBounds(174, 10, 120, 23);
		contentPane.add(lblNewLabel_4);
		
		text_Nombre1 = new JTextField();
		text_Nombre1.setBounds(106, 135, 96, 19);
		contentPane.add(text_Nombre1);
		text_Nombre1.setColumns(10);
		
		text_Apellido1 = new JTextField();
		text_Apellido1.setBounds(106, 175, 96, 19);
		contentPane.add(text_Apellido1);
		text_Apellido1.setColumns(10);
		
		text_Correo1 = new JTextField();
		text_Correo1.setBounds(330, 135, 96, 19);
		contentPane.add(text_Correo1);
		text_Correo1.setColumns(10);
		
		text_Contraseña1 = new JTextField();
		text_Contraseña1.setBounds(330, 175, 96, 19);
		contentPane.add(text_Contraseña1);
		text_Contraseña1.setColumns(10);
		
		registroFondo();
	}

	private void registroFondo() {
		JLabel lblfondo = new JLabel("PartysPlace");
		lblfondo.setBounds(-16, 0, 462, 284);
		lblfondo.setFont(new Font("Arial", Font.BOLD, 18));
		contentPane.add(lblfondo);
		contentPane.setLayout(null);
		
			ImageIcon icono2= new ImageIcon(Ventana_Registro.class.getResource("/imagenes/ChatGPT Image 19 may 2025, 12_20_18.png"));
			Image imagen2 = icono2.getImage().getScaledInstance( lblfondo.getWidth(),lblfondo.getHeight(), Image.SCALE_SMOOTH);
			ImageIcon iconoAjustado2 = new ImageIcon(imagen2);

			lblfondo.setIcon(iconoAjustado2);
	}
}
