package Aplicacion;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Image;

import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import java.awt.Color;

public class VentanaPrincipal extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VentanaPrincipal frame = new VentanaPrincipal();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public VentanaPrincipal() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		crearBoton();
		
		JTextArea txtrEnEs = new JTextArea();
		txtrEnEs.setForeground(new Color(255, 255, 255));
		txtrEnEs.setOpaque(false); // Hace que no se pinte el fondo
		txtrEnEs.setBackground(new Color(255, 255, 255));
		txtrEnEs.setWrapStyleWord(true);
		txtrEnEs.setLineWrap(true);
		txtrEnEs.setFont(new Font("Arial", Font.BOLD, 16));
		txtrEnEs.setText("En esta aplicación podrás encontrar las mejores discotecas por donde salir por cada ciudad de España");
		txtrEnEs.setBounds(90, 131, 297, 99);
		contentPane.add(txtrEnEs);
		
		JLabel lblfondo = new JLabel("PartysPlace");
		lblfondo.setBounds(-14, 0, 462, 284);
		lblfondo.setFont(new Font("Arial", Font.BOLD, 18));
		contentPane.add(lblfondo);
		contentPane.setLayout(null);
		
			ImageIcon icono2= new ImageIcon(VentanaPrincipal.class.getResource("/imagenes/ChatGPT Image 19 may 2025, 12_20_18.png"));
			Image imagen2 = icono2.getImage().getScaledInstance( lblfondo.getWidth(),lblfondo.getHeight(), Image.SCALE_SMOOTH);
			ImageIcon iconoAjustado2 = new ImageIcon(imagen2);

			lblfondo.setIcon(iconoAjustado2);
	}

	private void crearBoton() {
		JButton btnNewButton = new JButton("Continuar");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				Ventana2 G = new Ventana2();
				G.setVisible(true);
			}
		});
		btnNewButton.setFont(new Font("Arial", Font.PLAIN, 15));
		btnNewButton.setBounds(313, 216, 113, 37);
		contentPane.add(btnNewButton);
	}
}
