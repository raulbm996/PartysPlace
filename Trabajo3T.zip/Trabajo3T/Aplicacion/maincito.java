package Aplicacion;

import java.sql.SQLException;

public class maincito {

	public static void main(String[] args) throws SQLException 
	{
	
		VentanaPrincipal G = new VentanaPrincipal();
		G.setVisible(true);
		
		
		
		
		
		
		
	}

}